Instructions of installation and use in the document

tutorial.doc.gnrtv.cells25.edu.pdf

inside the zip package.

N·Joy

